//
// Created by mfbut on 3/9/2019.
//

#include "Move.h"

BattleShip::Move::Move(BattleShip::Player& moveMaker) : moveMaker(moveMaker) {}
